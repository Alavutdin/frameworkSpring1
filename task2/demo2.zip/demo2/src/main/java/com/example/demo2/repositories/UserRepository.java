package com.example.demo2.repositories;

import com.example.demo2.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserRepository {
    // объект подключения к базе данных
    private final JdbcTemplate jdbc;

    // Конструктор
    public UserRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // Получение всех пользователей из БД
    public List<User> findAll() {
        String sql = "SELECT * FROM userTable";

        RowMapper<User> userRowMapper = (r, i) -> {
            User rowObject = new User();
            rowObject.setId(r.getInt("id"));
            rowObject.setFirstName(r.getString("firstName"));
            rowObject.setLastName(r.getString("lastName"));
            return rowObject;
        };

        return jdbc.query(sql, userRowMapper);
    }
    // Добавление в БД
    public User save(User user) {
        String sql = "INSERT INTO userTable (firstName, lastName) VALUES (?, ?)"; //"INSERT INTO userTable VALUES (NULL, ?, ?)"
        jdbc.update(sql, user.getFirstName(), user.getLastName());
        return user;
    }
//    public List<User>findAll(){
//        String sql = "SELECT * FROM userTable";
//        return jdbc.query(sql, new  User);
//    }
    // Добавили новую команду удаления
    //В класс UserRepository добавить метод public void deleteById(int id)
    public void deleteBy(int id) {
        String sql = "DELETE FROM userTable WHERE id=?";
        jdbc.update(sql, id);
    }

}

